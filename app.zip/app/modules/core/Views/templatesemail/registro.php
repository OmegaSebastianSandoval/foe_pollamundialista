<div style='background:#3a599b;background-color:#3a599b;Margin:0px auto;max-width:600px'>
    <table align='center' border='0' cellpadding='0' cellspacing='0' role='presentation' style='background:#3a599b;background-color: #ffffff;
    width: 100%;
    border-top: 2px solid #3a599b;
    border-left: 2px solid #3a599b;
    border-right: 2px solid #3a599b;'>
        <tbody>
            <tr>
                <td style='direction:ltr;font-size:0px;padding:20px 0;padding-bottom:5px;padding-left:10px;padding-top:5px;text-align:center;vertical-align:top'>

                    <div class='m_30761971433926308mj-column-per-33' style='font-size:13px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%'>
                        <table border='0' cellpadding='0' cellspacing='0' role='presentation' style='vertical-align:top' width='100%'>
                            <tbody>
                                <tr>
                                    <td align='center' class='m_30761971433926308txttocenter' style='font-size:0px;padding:0px;word-break:break-word'>
                                        <table border='0' cellpadding='0' cellspacing='0' role='presentation' style='border-collapse:collapse;border-spacing:0px'>
                                            <tbody>
                                                <tr>
                                                    <td style='width:200px'><img height='auto' src='https://polla.foebbva.com/skins/page/images/logofoe.png' style='border:0;display:block;outline:none;text-decoration:none;height:auto;width:100%' width='125' class='CToWUd' data-bit='iit' jslog='138226; u014N:xr6bB; 53:WzAsMl0.'></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>
<div style='background:#3a599b; background-color:#3a599b; margin:0px auto;max-width:600px'>
    <table align='center' border='0' cellpadding='0' cellspacing='0' role='presentation' style='background:#3a599b; background-1C542A:#3a599b; width:100%'>
        <tbody>
            <tr>
                <td style='direction:ltr;font-size:0px;padding:20px;text-align:center;vertical-align:top'>
                    <div class='m_30761971433926308mj-column-per-100' style='font-size:13px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%'>
                        <table border='0' cellpadding='0' cellspacing='0' role='presentation' style='vertical-align:top' width='100%'>
                            <tbody>
                                <tr>
                                    <td align='center' class='m_30761971433926308nopad' style='font-size:0px;padding:10px 0px;word-break:break-word'>
                                        <div style='font-family:Roboto,Helvetica,sans-serif;font-size:18px;font-weight:600;line-height:1.2;text-align:start ;color:#ffffff'>

                                            <p style='color:#ffffff'>Apreciado usuario ha completado su registro de manera exitosa.</p><br>
                                           
                                        </div>
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>