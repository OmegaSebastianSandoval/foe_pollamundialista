<?php 
/**
* clase que genera la clase dependiente  de otro en la base de datos
*/
class Administracion_Model_DbTable_Dependjugadores extends Db_Table
{
	/**
	 * [ nombre de la tabla actual]
	 * @var string
	 */
	protected $_name = 'jugadores';

	/**
	 * [ identificador de la tabla actual en la base de datos]
	 * @var string
	 */
	protected $_id = 'id';

}