<?php 
/**
* clase que genera la clase dependiente  de resultado en la base de datos
*/
class Administracion_Model_DbTable_Dependpartidos extends Db_Table
{
	/**
	 * [ nombre de la tabla actual]
	 * @var string
	 */
	protected $_name = 'partidos';

	/**
	 * [ identificador de la tabla actual en la base de datos]
	 * @var string
	 */
	protected $_id = 'id';

}