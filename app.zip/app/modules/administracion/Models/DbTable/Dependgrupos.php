<?php 
/**
* clase que genera la clase dependiente  de equipo en la base de datos
*/
class Administracion_Model_DbTable_Dependgrupos extends Db_Table
{
	/**
	 * [ nombre de la tabla actual]
	 * @var string
	 */
	protected $_name = 'grupos';

	/**
	 * [ identificador de la tabla actual en la base de datos]
	 * @var string
	 */
	protected $_id = 'id';

}