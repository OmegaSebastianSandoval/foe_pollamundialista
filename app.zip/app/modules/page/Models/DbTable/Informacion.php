<?php 

/**
* 
*/
class Page_Model_DbTable_Informacion extends Db_Table
{
	/**
	 * [ nombre de la tabla actual]
	 * @var string
	 */
	protected $_name = 'info_pagina';

	/**
	 * [ identificador de la tabla actual en la base de datos]
	 * @var string
	 */
	protected $_id = 'info_pagina_id';
}