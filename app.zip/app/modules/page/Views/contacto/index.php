<div class="contact-container">
<?php 

  echo $this->home;

?>
</div>

<form action="">
  <input type="text">
</form>

<?php 

  echo $this->contenido2;

?>