

<?php 

  echo $this->contenido;

?>