<div class="container text-center">
	<br>
	<div class="titulo_partidos">Inscribase</div>
	<br>
	<p>Gracias por registrarse<br>sus números asignados para el sorteo son: <h3><?php echo $this->boletas; ?></h3></p>
	<br>
	<p><a href="/page/jugar"><button class="btn btn-rojo">Jugar</button></a> <a href="/page/invitar"><button class="btn btn-rojo">Invitar referido</button></a></p>
</div>